package com.maxxel10.conaapp

import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class WebConaGeneralActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_web_cona_general
        )
        val visor = findViewById<WebView>(R.id.webconageneral)

        visor.webChromeClient=object : WebChromeClient(){

        }
        visor.webViewClient = object : WebViewClient(){


        }
        val setting: WebSettings = visor.settings
        setting.javaScriptEnabled = true
        visor.loadUrl("http://www.conalep.edu.mx/inicio")

    }
}