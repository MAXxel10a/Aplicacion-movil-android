package com.maxxel10.conaapp


import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class ConaTlahuacActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cona_tlahuac)

        val visor = findViewById<WebView>(R.id.webconatlahuac)



        visor.webChromeClient=object : WebChromeClient(){

        }
        visor.webViewClient = object : WebViewClient(){




        }
        val setting: WebSettings = visor.settings
        setting.javaScriptEnabled = true
        visor.loadUrl("http://cdmx.conalep.edu.mx/tlahuac/home")

    }
}