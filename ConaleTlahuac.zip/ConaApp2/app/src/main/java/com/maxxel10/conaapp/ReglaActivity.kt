package com.maxxel10.conaapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.maxxel10.conaapp.R.layout

class ReglaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layout.activity_regla)
        val url = "http://www.ejemplo.com" // Aquí debes especificar el enlace que deseas abrir

        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("http://cdmx.conalep.edu.mx/tlahuac/Reglamento"))
        startActivity(intent)
    }
}