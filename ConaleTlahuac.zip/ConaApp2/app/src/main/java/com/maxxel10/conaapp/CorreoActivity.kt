package com.maxxel10.conaapp

import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class CorreoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_correo)
        val visor = findViewById<WebView>(R.id.webcorreo)

        visor.webChromeClient=object : WebChromeClient(){

        }
        visor.webViewClient = object : WebViewClient(){


        }
        val setting: WebSettings = visor.settings
        setting.javaScriptEnabled = true
        visor.loadUrl("https://outlook.office.com/mail/")

    }
}