package com.maxxel10.conaapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment


class ElectricosFragment : Fragment(R.layout.fragment_electricos) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        val url = "http://cdmx.conalep.edu.mx/tlahuac/Ekin18" // URL del enlace que deseas abrir

        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        startActivity(intent)
    }

    }
