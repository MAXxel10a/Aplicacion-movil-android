package com.maxxel10.conaapp

import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import androidx.fragment.app.Fragment
import androidx.navigation.NavController
import androidx.navigation.fragment.findNavController

class InfoFragment : Fragment(R.layout.fragment_info) {
    private lateinit var navController: NavController

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {


        super.onViewCreated(view, savedInstanceState)

        val btn1 = requireView().findViewById<ImageButton>(R.id.button1)
        val btn2 = requireView().findViewById<ImageButton>(R.id.button2)
        val btn3 = requireView().findViewById<ImageButton>(R.id.button3)
        val btn4 = requireView().findViewById<ImageButton>(R.id.button4)
        val btn6 = requireView().findViewById<ImageButton>(R.id.automotriz)
        val btn7 = requireView().findViewById<ImageButton>(R.id.conta)
        val btn8 = requireView().findViewById<ImageButton>(R.id.electricos)
        val btn9 = requireView().findViewById<ImageButton>(R.id.button8)
        val btn10= requireView().findViewById<ImageButton>(R.id.button6)
        val btn11= requireView().findViewById<ImageButton>(R.id.button9)
        val btn12= requireView().findViewById<ImageButton>(R.id.button7)
        val btn13= requireView().findViewById<ImageButton>(R.id.conatlahuac)
        val btn14= requireView().findViewById<ImageButton>(R.id.conageneral)
        val btn15= requireView().findViewById<ImageButton>(R.id.conacdmx)
        val btn16 = requireView().findViewById<ImageButton>(R.id.button10)
        val btn17 = requireView().findViewById<ImageButton>(R.id.button11)
        val btn18 = requireView().findViewById<ImageButton>(R.id.button12)
        val btn19 = requireView().findViewById<ImageButton>(R.id.button13)

        btn1.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_calendarioFragment2)
        }

        btn2.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_formatosFragment)
        }

        btn3.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_reglaActivity)
        }

        btn4.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_contactoFragment)
        }


        btn6.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_automotrizFragment)
        }

        btn7.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_contaFragment)
        }

        btn8.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_electricosFragment)
        }
            //web para horarios
        btn9.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_webHorariosActivity)
        }

        btn10.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_estructuraFragment)
        }

        btn11.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_intercambioFragment)
        }

        btn12.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_valoresFragment)
        }

        btn13.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_conaTlahuacActivity)
        }

        btn14.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_webConaGeneralActivity)
        }

        btn15.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_webConaCdmxActivity)
        }

        btn16.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_correoActivity)
        }

        btn17.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_webPortalAlumnoActivity)
        }

        btn18.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_webPortalDocenteActivity)
        }

        btn19.setOnClickListener{
            findNavController().navigate(R.id.action_infoFragment_to_webPortalAdministrativoActivity)
        }

    }
}