package com.maxxel10.conaapp

import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class WebPortalDocenteActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web_portal_docente)
        val visor = findViewById<WebView>(R.id.webdocentes)

        visor.webChromeClient=object : WebChromeClient(){

        }
        visor.webViewClient = object : WebViewClient(){


        }
        val setting: WebSettings = visor.settings
        setting.javaScriptEnabled = true
        visor.loadUrl("http://administrativo.conalep.edu.mx/pad/portal/inicio")

    }
}