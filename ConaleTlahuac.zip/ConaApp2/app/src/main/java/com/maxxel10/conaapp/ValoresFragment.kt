package com.maxxel10.conaapp

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment

class ValoresFragment : Fragment(R.layout.fragment_valores) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


    }

}