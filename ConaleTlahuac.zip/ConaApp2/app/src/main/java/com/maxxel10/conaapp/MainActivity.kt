package com.maxxel10.conaapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuth.AuthStateListener
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var authStateListener: AuthStateListener

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Base_Theme_ConaApp)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btningresar = findViewById<Button>(R.id.btningresar)
        val txtemail = findViewById<EditText>(R.id.txtemail)
        val txtcontra = findViewById<EditText>(R.id.txtcontra)

        firebaseAuth = Firebase.auth

        btningresar.setOnClickListener {
            signIn(txtemail.text.toString(),txtcontra.text.toString())
            val correo = txtemail.text.toString()


        }
    }




    private fun signIn(email:String, password:String){
        firebaseAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(this){task ->
            if(task.isSuccessful){
                val user = firebaseAuth.currentUser
                Toast.makeText(baseContext,"Autenticacion Exitosa", Toast.LENGTH_SHORT).show()
                //aqui vamos a ir a la segunda activity
                val i = Intent(this, MainActivity2::class.java)
                startActivity(i)
            }else{
                Toast.makeText(baseContext,"ERROR de email y o contraseña", Toast.LENGTH_SHORT).show()

            }
        }
    }
}