package com.maxxel10.conaapp

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment

class ContactoFragment : Fragment(R.layout.fragment_contacto) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)






        }

    }
