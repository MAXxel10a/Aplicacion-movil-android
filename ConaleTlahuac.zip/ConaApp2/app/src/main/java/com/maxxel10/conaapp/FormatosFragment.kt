package com.maxxel10.conaapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment


class FormatosFragment : Fragment(R.layout.fragment_formatos) {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val view = inflater.inflate(R.layout.fragment_formatos, container, false)

        val linkTextView1 = view.findViewById<TextView>(R.id.textView1)
        val linkTextView2 = view.findViewById<TextView>(R.id.textView2)
        val linkTextView3 = view.findViewById<TextView>(R.id.textView3)


        linkTextView1.setOnClickListener {
            val url = "http://cdmx.conalep.edu.mx/tlahuac/sites/default/files/TLAHUAC/FormatosEscolares/SolicitudServicioPracticas.docx" // Reemplaza con el enlace que deseas abrir
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse(url)
            startActivity(intent)
        }

        linkTextView2.setOnClickListener {
            val url = "http://cdmx.conalep.edu.mx/tlahuac/sites/default/files/TLAHUAC/FormatosEscolares/InformeServicio.docx" // Reemplaza con el enlace que deseas abrir
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse(url)
            startActivity(intent)
        }

        linkTextView3.setOnClickListener {
            val url = "http://cdmx.conalep.edu.mx/tlahuac/sites/default/files/TLAHUAC/FormatosEscolares/InformePracticas.docx" // Reemplaza con el enlace que deseas abrir
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse(url)
            startActivity(intent)
        }

        return view
    }


}
