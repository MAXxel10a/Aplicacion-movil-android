package com.maxxel10.conaapp

import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class IntranetActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_intranet)



        val visor = findViewById<WebView>(R.id.web4)

        visor.webChromeClient=object : WebChromeClient(){

        }
        visor.webViewClient = object : WebViewClient(){




        }
        val setting: WebSettings = visor.settings
        setting.javaScriptEnabled = true
        visor.loadUrl("http://186.96.29.210/(S(zgzstwxlsjqyees3onqjqlbl))/tlahuac/servicios/menus/iniciosesion.aspx")

    }
}