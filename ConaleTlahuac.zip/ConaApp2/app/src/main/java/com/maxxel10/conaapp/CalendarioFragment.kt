package com.maxxel10.conaapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment


 class CalendarioFragment : Fragment() {
     private lateinit var webView:WebView


     override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
         val view = inflater.inflate(R.layout.fragment_calendario, container, false)

         webView = view.findViewById(R.id.webcale)
         webView.getSettings().setBuiltInZoomControls(true)
         webView.settings.javaScriptEnabled = true
         webView.webViewClient = WebViewClient()
         webView.loadUrl("https://conaapp.000webhostapp.com/Conaapp/img/calendarioconalep.jpg")

         return view
     }
 }
